public class Automorph {
    public static boolean isAutomorphic(int n) {
        int nLength = getIntLength(n);
        int nSquared = power(n, 2);
        int lastDigits = getLastDigits(nSquared, nLength);
        return nSquared == lastDigits;
    }

    // Utilities
    public static int getLastDigits(int n, int length) {
        // Sebenarnya n definit positif, tapi cek aja
        if (n < 0) { // kalo negatif bikin positif dulu
            n = -n;
        }
        int powerOfTen = power(10, length);
        int intSubstring = n % powerOfTen;
        return intSubstring;
    }

    public static int power(int n, int exponent) {
        int powerResult = 1;
        for (int i = 0; i < exponent; i++) { // kalikan 1 dengan n [power] kali
            powerResult *= n;
        }
        return powerResult;
    }

    public static int getIntLength(int n) {
        int intLength = 0;
        while (n != 0) {
            n = n / 10;
            intLength += 1;
        }
        return intLength;
    }
}
